package com.uas.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.uas.bean.StudentBean;

@Repository
@Transactional
public class StudentDAOImpl implements IStudentDAO{

	@PersistenceContext
	private EntityManager em;
	public int addStudentDetails(StudentBean rc) {
		System.out.println("in Dao");
		em.persist(rc);
		return rc.getApplicationId();
	}
	
	
	

}
