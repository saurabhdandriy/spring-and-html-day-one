package com.uas.dao;

import com.uas.bean.StudentBean;

public interface IStudentDAO {

	int addStudentDetails(StudentBean rc);

}
