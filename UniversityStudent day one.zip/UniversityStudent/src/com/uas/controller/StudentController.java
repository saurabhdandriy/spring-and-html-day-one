package com.uas.controller;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.uas.bean.StudentBean;
import com.uas.service.IStudentService;


@Controller
public class StudentController {
	
	@RequestMapping("StudentRegistration")
	public String getHome(Model m){
		m.addAttribute("studentObj",new StudentBean());

		return "StudentRegistration";
	}

	@Autowired
	private IStudentService serv;

	@RequestMapping(value="store",method=RequestMethod.POST)
	public String storeStudentDetails(Model m , @ModelAttribute("studentObj") StudentBean rc){
		System.out.println("in adding method");
		String target = null;
		
		
		int appid = serv.addStudentDetails(rc);
		System.out.println("rid taken"+ appid);
		if(appid>0)
		{
			System.out.println("Cheking rid ");
			m.addAttribute("msg","You have been registered successfully");
			m.addAttribute("appid", appid);
			target="success";
		}
		else
		{
			target= "StudentRegistration";
		}
		
		return target;
	}
	
	
	
	

}
