package com.uas.service;

import com.uas.bean.StudentBean;

public interface IStudentService {

	int addStudentDetails(StudentBean rc);

}
