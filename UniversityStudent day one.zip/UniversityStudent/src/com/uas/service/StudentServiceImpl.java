package com.uas.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uas.bean.StudentBean;
import com.uas.dao.IStudentDAO;
@Service
public class StudentServiceImpl implements IStudentService {
	@Autowired
private IStudentDAO dao;
	@Override
	public int addStudentDetails(StudentBean rc) {
		System.out.println("in service");
		int appid = dao.addStudentDetails(rc);
		return appid;
	}

}
