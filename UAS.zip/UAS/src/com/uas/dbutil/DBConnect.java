package com.uas.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	static Connection conn= null; 
	
	  public static Connection getConnected() throws SQLException {
		  conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1112","training1112");
		    return conn;
	  }
}
