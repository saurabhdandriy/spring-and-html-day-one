package com.uas.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.uas.bean.ScheduleBean;
import com.uas.service.IScheduleService;

@Controller
public class UASController {
	@Autowired
	private IScheduleService iss;
	
	@RequestMapping("schedule")
	public String goSchedulePage()
	{
		return "schedule";
	}

	@RequestMapping("addscheduledetails")
	public String goAddSchedulePage(Model m)
	{
		m.addAttribute("scheduleObj",new ScheduleBean());
		return "addscheduledetails";
	}
	

	
	@RequestMapping(value="addsuccess",method=RequestMethod.POST)
	public String addScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
	{
	String target=null;
		int sid;
		sid=iss.addScheduleDetails(sb);
		if(sid>0)
		{
			m.addAttribute("msg","schedule data added  successfully The schedule id is...");
			m.addAttribute("scheduleId", sid);
			target="addsuccess";
		}
		else
		{
			target="home";
		}
		return target;
	}
	



@RequestMapping("viewscheduledetails")
public ModelAndView viewAll()
{
	ModelAndView mv= new ModelAndView();
	ArrayList<ScheduleBean> schelist= iss.viewAllScheduleDetails();
	mv.setViewName("viewsuccess");
	mv.addObject("sechdata",schelist);
	return mv;
}



}
