package com.uas.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;

/*create table Programs_Scheduled(
Schedule_Program_Id varchar2(5) primary key,
Program_Name varchar2(15),
Location varchar2(10),
StartDate date,
EndDate date,
Sessions_Per_Week number(5));*/

@Entity
@NamedQuery(name="getAllSchedule",query="select sb from ScheduleBean sb")
@Table(name="Programs_Scheduled")
public class ScheduleBean {
	
	@Id
	@GeneratedValue
	//@Column(name="Schedule_Program_Id")
	private int scheduleProgramId;
	//@Column(name="Program_Name")
	private String programName;
	//@Column(name="Location")
	private String location;
	//@Column(name="StartDate")
	private String startDate;
	//@Column(name="EndDate")
	private String endDate;
	//@Column(name="Sessions_Per_Week")
	private int  SessionsPerWeek;

	public int getSessionsPerWeek() {
		return SessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public ScheduleBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ScheduleBean(int scheduleProgramId, String programName,
			String location, String startDate, String endDate,
			int sessionsPerWeek) {
		super();
		this.scheduleProgramId = scheduleProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public int getScheduleProgramId() {
		return scheduleProgramId;
	}
	public void setScheduleProgramId(int scheduleProgramId) {
		this.scheduleProgramId = scheduleProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "ScheduleProgramId  =  " + scheduleProgramId
				+ ", ProgramName  =  " + programName + ", Location  =  " + location
				+ ", StartDate  =  " + startDate + ", EndDate  =  " + endDate
				+ ", SessionsPerWeek  =  " + SessionsPerWeek;
	}
	
}
