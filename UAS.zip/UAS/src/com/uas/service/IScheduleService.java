package com.uas.service;

import java.util.ArrayList;

import com.uas.bean.ScheduleBean;


public interface IScheduleService {

	int addScheduleDetails(ScheduleBean sb);

	ArrayList<ScheduleBean> viewAllScheduleDetails();

}
