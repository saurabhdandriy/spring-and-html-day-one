package com.uas.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.uas.bean.ScheduleBean;

@Repository
@Transactional
public class ScheduleDAOImplementation implements IScheduleDAO {

	@PersistenceContext 
	private EntityManager em;
	@Override
	public int addScheduleDetails(ScheduleBean sb) {
		em.persist(sb);
		return sb.getScheduleProgramId();
	}
	
/*	@Override
	public ArrayList<Recharge> viewAllDetails() {
		Query q=em.createNamedQuery("getAllRecharge");
		return (ArrayList<Recharge>) q.getResultList();
	}*/
	
	@Override
	public ArrayList<ScheduleBean> viewAllScheduleDetails() {
		Query q=em.createNamedQuery("getAllSchedule");	
		
		return (ArrayList<ScheduleBean>) q.getResultList();
	}

}
