package com.recharge.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recharge.bean.Recharge;
import com.recharge.dao.IRechargeDao;
@Service
public class RechargeServicesImpl implements IRechargeServices{

	@Autowired
	private IRechargeDao ird;
	@Override
	public int addRecharge(Recharge rr) {
		int rid=ird.addRecharge(rr);
		
		return rid;
	}
	@Override
	public ArrayList<Recharge> viewAllDetailss() {

		return ird.viewAllDetails();
	}
	

}
