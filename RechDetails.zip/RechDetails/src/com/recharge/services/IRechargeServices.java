package com.recharge.services;

import java.util.ArrayList;

import com.recharge.bean.Recharge;

public interface IRechargeServices {

	int addRecharge(Recharge rr);

	ArrayList<Recharge> viewAllDetailss();

}
