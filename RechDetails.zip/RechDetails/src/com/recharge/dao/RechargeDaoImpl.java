package com.recharge.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recharge.bean.Recharge;

@Repository
@Transactional
public class RechargeDaoImpl implements IRechargeDao{

	@PersistenceContext
	private EntityManager em;
	@Override
	public int addRecharge(Recharge rr) {
		
		em.persist(rr);
		return rr.getRechargeId();
		
		
	}
	@Override
	public ArrayList<Recharge> viewAllDetails() {
		Query q=em.createNamedQuery("getAllRecharge");
		return (ArrayList<Recharge>) q.getResultList();
	}
	

}
