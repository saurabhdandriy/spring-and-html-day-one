package com.recharge.dao;

import java.util.ArrayList;

import com.recharge.bean.Recharge;

public interface IRechargeDao {

	public int addRecharge(Recharge rr);

	public ArrayList<Recharge> viewAllDetails();

}
