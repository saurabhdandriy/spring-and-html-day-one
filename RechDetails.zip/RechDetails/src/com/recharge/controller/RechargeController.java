package com.recharge.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



import org.springframework.web.servlet.ModelAndView;

import com.recharge.bean.Recharge;
import com.recharge.services.IRechargeServices;


@Controller
public class RechargeController {

	@Autowired
	private IRechargeServices irs=null;
	
	@RequestMapping("home")
	public String goHome()
	{
		return "home";
	}
	@RequestMapping("recharge")
	public String goRecharge(Model m)
	{
		m.addAttribute("rechargeObj",new Recharge());
		return "recharge";
	}
@RequestMapping(value="dorecharge",method=RequestMethod.POST)
	public String addRechargeDetails(Model m,@ModelAttribute("rechargeObj") Recharge rr)
	{
	String target=null;
		int rid=irs.addRecharge(rr);
		if(rid>0)
		{
			m.addAttribute("msg","Recharge done successfully your id is..");
			m.addAttribute("rechargeid", rid);
			target="success";
		}
		else
		{
			target="home";
		}
		return target;
	}


@RequestMapping(value="viewall")
public ModelAndView viewAll()
{
	ModelAndView mv=new ModelAndView();
	ArrayList<Recharge> rechlist= irs.viewAllDetailss();
	mv.setViewName("viewall");
	mv.addObject("data",rechlist);
	return mv;
}

@RequestMapping("rec")
public String display()
{
	return "rec";
}








}
