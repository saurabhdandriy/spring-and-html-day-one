package com.recharge.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;

@Entity
@NamedQuery(name="getAllRecharge",query="select r from Recharge r")
public class Recharge {
	@Id
	@GeneratedValue
	private int rechargeId;
	private String planName;
	private int amount;
	private String mobileNumber;
	private String description;
	private String rechargeDate;
	public String getRechargeDate() {
		return rechargeDate;
	}
	public void setRechargeDate(String rechargeDate) {
		this.rechargeDate = rechargeDate;
	}
	public int getRechargeId() {
		return rechargeId;
	}
	public void setRechargeId(int rechargeId) {
		this.rechargeId = rechargeId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Recharge() {
	}
	public Recharge(int rechargeId, String planName, int amount,
			String mobileNumber, String description,String rechargeDate) {
		super();
		this.rechargeDate = rechargeDate;
		this.rechargeId = rechargeId;
		this.planName = planName;
		this.amount = amount;
		this.mobileNumber = mobileNumber;
		this.description = description;
	}
	@Override
	public String toString() {
		return "Recharge [rechargeId=" + rechargeId + ", planName=" + planName
				+ ", amount=" + amount + ", mobileNumber=" + mobileNumber
				+ ", description=" + description + ", rechargeDate="
				+ rechargeDate + "]";
	}
	
}
